# 07 | Implantação, transferência e sustentação

**FICTÍCIO — Fase III em cenário futuro.** Datas e resultados abaixo são roteiro/teste, não fatos ocorridos. O piloto PIL-01 do arquivo `05` foi reprovado no cenário; a Onda 1 só pode começar após correção e novo piloto aceito. Não há ativação real de agente nem transferência assinada.

## Etapa 10: ondas e habilitação

| Onda/data proposta | Grupo/ativo | Pré-condição | Verificação observável |
| --- | --- | --- | --- |
| 0, até 29/01/27 | Corrigir SOP-CAM-01 e repetir piloto | 9/10 cards completos; zero publicação bloqueada | Registro de piloto e aceite dos executores |
| 1, 05–19/02/27 | Growth, Supply, Qualidade: gate e alçadas | Onda 0 aceita | 2 operadores executam card sem ajuda; 90% gates |
| 2, 20/02–12/03/27 | Finanças, CS: margem e promessa | Onda 1 estável | Margem documentada e promessa versionada |
| 3, 13–19/03/27 | Seis líderes: rituais, painel e escalonamento | KPIs conciliados | Ata com decisão, dono, prazo e retorno |

Matriz por papel: Luiza abre/decide campanha na alçada; Bruno verifica saldo e previsão; Marina libera Qualidade; Paula calcula margem e caixa; Tiago valida promessa; Helena decide exceção. Cada papel recebe guia rápido com um caso normal e um bloqueado. A verificação é observação de execução, não presença em treinamento. Barreiras ADO-01: saldo sem horário; ADO-02: margem projetada sem frete final; ADO-03: card duplicado. Donos Bruno, Paula e Luiza, respectivamente; resolução exigida antes da onda seguinte.

**Camada agêntica, especificação apenas:** se contratada e autorizada, ler somente ativos publicados da Nutrivance e status de Action Points aprovados, solicitar atualização ao dono, citar fonte e encaminhar dúvida/decisão a humano. Nunca alterar alçada, aprovar campanha, publicar SKU ou inferir cumprimento de silêncio. Dono operacional Paula; desligamento e revogação definidos no plano de continuidade. Status: não ativada; qualquer teste usa fixture isolada.

## Etapa 11: operação assistida e autonomia

Quatro degraus previstos: DirectScal conduz com líder presente; condução conjunta; líder conduz com observação; líder conduz sozinho com revisão remota. Registro de ensaio OA-01: Luiza 2, Bruno 1, Marina 2, Paula 1, Tiago 1, Helena 1 em 19/03/27. **É uma situação fictícia de progresso incompleto**, portanto transferência bloqueada. Para autonomia: cada líder chega ao degrau 4 por quatro semanas, duas reuniões seguidas com dados/decisões corretos, 90% dos Action Points com estado verificável, duas pessoas capazes de operar PROC-02, e nenhum gate de Qualidade contornado. Um líder por área demonstra rotina de melhoria: identifica desvio, registra hipótese, testa ajuste, mede efeito e atualiza dono do ativo.

Ativos e propriedade proposta: SOP-CAM-01 → Luiza; previsão PROC-02 → Bruno; padrão de Qualidade → Marina; árvore de indicadores → Paula; taxonomia de chamados → Tiago; charter/alçadas → Helena. Cada alteração tem versão, data, razão, aprovador e comunicação ao grupo. Modalidade do agente: **desativado até decisão formal**; se ativado em teste, contrato, acesso, privacidade e supervisão precisam ser separados. Termo de transferência é minuta e não contém assinatura fictícia apresentada como real.

## Plano de continuidade

Após saída hipotética da DirectScal, Paula convoca revisão semanal por oito semanas e auditoria mensal de 10 cards, 10 promessas e 5 previsões; Helena revisa alçadas trimestralmente. Indicadores KPI-01–06 preservam a definição de `02`; mudanças de denominador geram nova série. Incidentes de qualidade são tratados pelo processo próprio e bloqueiam campanha. Se indicador ficar abaixo do limite por duas semanas, líder registra causa e plano; decisões sobre produto/capital continuam humanas. Verificação de autonomia proposta: 16/04/27; avaliação de sustentação proposta: 30/04/27. Ambas **pendentes**.

## Avaliação de sustentação: formulário ainda vazio

| Item | Linha de base | Resultado posterior | Estado |
| --- | --- | --- | --- |
| OMDx Nutrivance, mesmas perguntas e segmentação | **Não disponível** | Não disponível | Comparação bloqueada; não usar pesquisa de outro tenant |
| Envio no prazo | 85% em out/26 | Não medido | Pendente de exportação |
| Chamados por prazo divergente | 37 em out/26 | Não medido | Pendente de auditoria de classificação |
| Gate completo | 2/15 em out/26 | Não medido | Pendente de cards |
| Margem operacional | 6% em out/26 | Não medido | Pendente de DRE conciliada |
| Práticas mantidas/abandonadas | Não aplicável | Não observado | Entrevistar e observar |

Fatores externos a registrar: sazonalidade de suplementos, campanhas de mercado, preços de insumos, troca de operador/fabricante e mudanças de equipe. Conclusão de sustentação: **não avaliável**. Recomendação: realizar avaliação somente após implantação e quatro semanas de autonomia comprovada; se falhar, abrir novo ciclo de investigação com escopo menor. Nenhum efeito é atribuído à intervenção neste pacote.
