# 06 | Governança, sistemas e preparação para mudança

**FICTÍCIO — Fase II, etapas 08–09 e frente transversal.** Ativos A-03/A-04/A-05; configuração e uso são planos de ensaio.

## Árvore de objetivos e indicadores

| Nível | Objetivo | Indicador | Base out/26 | Meta de teste | Dono |
| --- | --- | --- | --- | --- | --- |
| Estratégico/trimestral | Crescer com margem e serviço | Receita anual móvel; margem operacional | R\$ 48 mi; 10% anual, 6% em out | Margem mensal ≥8% por 2 meses, sem meta de receita que force campanha | Helena/Paula |
| Desempenho/mensal | Prometer prazo confiável | KPI-01 e KPI-02 | 85%; 37 chamados | ≥92%; ≤20 chamados/mês | Bruno/Tiago |
| Execução/semanal | Usar gate antes de publicar | KPI-05 e KPI-04 | 2/15 completos; 6/15 reabertos | ≥90% completos; ≤2/15 reabertos | Luiza |
| Execução/semanal | Previsão transferível | Versões registradas e substitutos capazes | Versão não controlada; cobertura parcial | 100% versões; 2 substitutos observados | Bruno |

Metas são propostas, não resultados alcançados. Receita por canal usa os percentuais do índice; margem de campanha (piso 8%) é distinta de margem operacional mensal. Nenhuma variação de resultado é atribuída aos ativos sem avaliação de fatores externos.

## Rituais, ata e Action Points

| Fórum | Cadência | Entrada | Saída e decisão |
| --- | --- | --- | --- |
| Coordenação de execução | Diária, 15 min | Cards bloqueados, estoque, qualidade | Impedimento, dono, prazo e escalonamento |
| Serviço e campanha | Semanal, 45 min | KPI-01/02/04/05, PIL-01 | Decisão de ajuste, Action Point e revisão do anterior |
| Performance | Mensal, 60 min | FIN-01, margem por canal, caixa, serviço | Realocação de recursos e riscos |
| Direção | Trimestral, 90 min | Objetivos, capacidade e mercado | Prioridades, trade-offs, limites de investimento |

Modelo de ata: data, presentes, dados/versão, decisão, alternativas, responsável, prazo, evidência, risco e retorno. **Exemplo ATA-FUT-01 (fictício para 13/11/26):** decidir adiar campanha de creatina por falta de snapshot de saldo; Luiza dona; Bruno entrega dado até 16/11; Paula revisa margem em 17/11; publicar somente com três gates. Se prazo vencer, escalar a Helena; silêncio não é aprovação. Este exemplo não representa reunião ocorrida.

## Arquitetura da informação e regra de uso

| Dado | Fonte oficial | Dono | Atualização | Controle |
| --- | --- | --- | --- | --- |
| Pedido, estoque e custo padrão | ERP (SYS-01) | Bruno/Paula | Evento de pedido e fechamento diário | Snapshot com data; divergência bloqueia oferta |
| Preço e oferta publicada | E-commerce/marketplace (SYS-02) | Luiza | Publicação | Card vinculado e versão |
| Condição B2B | CRM (SYS-03) | Caio | Aprovação de proposta | Exceção registrada |
| Campanha/gate e lançamento | Tarefas (SYS-04) | Luiza/Marina | Cada etapa | Campos obrigatórios, histórico de decisão |
| Chamado e causa | Help desk (SYS-05) | Tiago | Atendimento | Taxonomia auditada mensalmente |
| Previsão e margem projetada | Planilha controlada (SYS-06), até piloto | Bruno/Paula | Semanal/por campanha | Autor, versão, premissas e link no card |

Configuração proposta: campos do card de campanha para SKU, canal, janela, status de Qualidade, snapshot de saldo, margem com premissas, decisor, prazo, promessa e link de ocorrência. Status: briefing → aguardando gates → pronto para decidir → aprovado → publicado → revisado; bloqueado é estado explícito com motivo. A automação apenas avisa e bloqueia etapa incompleta; **não aprova** investimento, produto ou exceção. Não conectar Slack, ERP ou agente real sem autorização, configuração e piloto próprios. Indicadores de uso: percentual de cards completos, decisões com evidência e versões de previsão.

## Plano de mudança

| Grupo | Impacto | Patrocinador/ação | Preparação e resistência |
| --- | --- | --- | --- |
| Growth/Comercial | Data de campanha depende de gates | Helena explica trade-off; Luiza testa card | Objeção “perda de velocidade”: medir tempo total e retrabalho |
| Supply | Snapshot e reserva antes da promessa | Bruno treina 2 substitutos | Planilha extra: substituir dupla digitação quando processo estabilizar |
| Qualidade | Liberação explícita no calendário | Rafael/Marina demonstram bloqueio | Evitar que gate seja interpretado como aprovação tácita |
| Finanças | Margem por campanha antes da decisão | Paula define premissas e piso | Ajustar carga de análise com templates simples |
| CS | Promessa recebe fonte e versão | Tiago testa atualização | Medir chamados classificados incorretamente |

Comunicação proposta: direção anuncia motivo e limites em 09/11, líderes demonstram o fluxo em 12/11, operadores participam do piloto em janeiro, revisão semanal de objeções. Mapa de patrocínio: Helena patrocina e decide exceções; Rafael protege Qualidade; cada líder responde pela adoção em sua área. Registro RES-01: risco de cards virarem burocracia; resposta = medir tempo e manter somente campos que suportam decisão ou rastreio. Capacidade de mudança: até duas frentes simultâneas por área. **Prontidão ADKAR e dimensão 6 OMDx da Nutrivance não medidas**; esta é uma limitação expressa do plano.
