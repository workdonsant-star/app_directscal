# 02 | Finanças, KPIs e registros de operação

**FICTÍCIO.** Valores gerenciais sintéticos, em R\$ milhões quando não indicado. Base anual móvel nov/25–out/26; trimestre ago–out/26. Não são extratos, demonstrações auditadas ou documentos de prospect real.

## DRE gerencial

| Linha FIN-01 | Ago/26 | Set/26 | Out/26 | Ano móvel |
| --- | ---: | ---: | ---: | ---: |
| Receita líquida | 3,70 | 4,00 | 4,30 | 48,00 |
| Custo dos produtos vendidos | 1,78 | 2,00 | 2,19 | 24,00 |
| Lucro bruto | 1,92 | 2,00 | 2,11 | 24,00 |
| Comercial/marketing | 0,96 | 1,08 | 1,22 | 12,00 |
| Gerais/administrativas | 0,57 | 0,60 | 0,63 | 7,20 |
| Resultado operacional gerencial | 0,39 | 0,32 | 0,26 | 4,80 |
| Margem operacional | 10,5% | 8,0% | 6,0% | 10,0% |

Esta tabela mostra resultado, não movimentação de dinheiro. Por coluna, receita − CPV − despesas = resultado operacional gerencial. A receita do ano móvel anterior é 48 ÷ 1,32 = R\$ 36,364 milhões (arredondado), pois R\$ 48 milhões representam o valor anterior acrescido de 32%. Agosto a outubro já integram o ano móvel.

## Caixa gerencial

| Linha FIN-02 | Ago/26 | Set/26 | Out/26 |
| --- | ---: | ---: | ---: |
| Saldo inicial | 3,46 | 3,20 | 2,94 |
| Variação líquida do mês | −0,26 | −0,26 | −0,33 |
| Saldo final | 3,20 | 2,94 | 2,61 |

Em cada mês, saldo inicial + variação líquida = saldo final. Esta tabela mostra apenas a movimentação líquida; não há detalhamento de recebimentos, pagamentos, capital de giro, investimentos e financiamento suficiente para explicar a diferença entre caixa e resultado da DRE. Não inferir solvência sem conciliação bancária.

## Painel de linha de base

| ID/indicador | Ago | Set | Out | Definição/denominador | Fonte |
| --- | ---: | ---: | ---: | --- | --- |
| KPI-01 pedidos enviados no prazo | 94% | 90% | 85% | Pedidos enviados até a data prometida / pedidos enviados; data congelada na confirmação | ERP + operador, exportação fictícia |
| KPI-02 chamados por prazo divergente | 16 | 24 | 37 | Chamados classificados como prazo divergente; categorias ainda exigem auditoria | Help desk fictício |
| KPI-03 SKUs com ruptura ≥1 dia | 5 | 7 | 10 | SKUs ativos com saldo vendável zero em algum dia do mês | ERP fictício |
| KPI-04 campanhas reabertas | 2/12 | 4/14 | 6/15 | Cards reabertos após primeira aprovação / campanhas encerradas | Tarefas fictícias |
| KPI-05 campanhas com gate completo | 3/12 | 3/14 | 2/15 | Cards com qualidade, estoque e margem anexados antes da publicação | Tarefas fictícias |
| KPI-06 margem operacional | 10,5% | 8,0% | 6,0% | Resultado operacional / receita líquida | FIN-01 |

Não atribuir a queda da margem a marketing sem decompor mix, descontos, frete e custo de aquisição. O gate completo é indicador de uso; envio no prazo e margem são resultados. Meta proposta para piloto: gate ≥90%, envio no prazo ≥92%, chamados de prazo ≤20/mês, margem ≥8% por dois meses, com denominadores preservados.

## Processos e sistemas atuais

| ID | Fluxo | Entrada → saída | Sistema oficial / lacuna |
| --- | --- | --- | --- |
| PROC-01 | Campanha DTC | Briefing → publicação → pedido | Tarefas para card, e-commerce para oferta; aprovação de margem em planilha |
| PROC-02 | Reposição | Ruptura prevista → compra → saldo vendável | ERP para pedido/estoque; previsão em planilha sem versionamento |
| PROC-03 | Novo SKU | Proposta → qualidade/rotulagem → estoque → canal | Checklist parcial em tarefas, aprovação de qualidade em repositório |
| PROC-04 | Pedido B2B | Cotação → condição → faturamento → entrega | CRM + ERP; desconto excepcional por mensagem |
| PROC-05 | Reclamação de prazo | Chamado → causa → resposta/correção | Help desk; causa em campo livre |

**SYS-01:** ERP = pedidos, estoque e custos padrão; **SYS-02:** e-commerce/marketplaces = oferta e promessa; **SYS-03:** CRM = oportunidade B2B; **SYS-04:** ferramenta de tarefas = campanha e lançamento; **SYS-05:** help desk = chamados; **SYS-06:** planilha = previsão e margem. Não há evidência de integração automática. A arquitetura alvo está em `06` e não pressupõe troca de ferramenta.

## Ocorrências e atas

| ID | Data | Registro sintético | Limite |
| --- | --- | --- | --- |
| OCC-01 | 09/09/26 | Campanha de creatina aguardou confirmação de saldo por 2 dias úteis | Card não mostra quando a solicitação foi enviada |
| OCC-02 | 18/09/26 | Arte final de rótulo mudou após anúncio interno de data | Não prova falha de Qualidade |
| OCC-03 | 03/10/26 | Promoção de proteína foi replanejada por margem projetada de 5%, abaixo do piso de 8% | Planilha não registra custo de frete final |
| OCC-04 | 24/10/26 | 37 chamados do mês por prazo divergente; amostra de 8 refere-se a promessa antiga | Classificação dos demais 29 não auditada |
| ATA-01 | 07/10/26 | Reunião comercial solicitou piso por canal; Paula entrega proposta em 14/10 | Proposta sem aprovação formal |
| ATA-02 | 14/10/26 | Reunião de lançamento propôs bloquear anúncio sem liberação de Qualidade | Sem registro de adoção |
| ATA-03 | 28/10/26 | Direção adiou decisão de alçadas de promoção e reposição | Prazo e responsável ausentes |

## Inventário de evidências

FIN-01 = DRE gerencial; FIN-02 = planilha sintética de caixa; KPI-01–06 = painéis; ORG-01/RH-01 = `01`; PROC-01–05/SYS-01–06/OCC-01–04/ATA-01–03 = este arquivo. Todos têm status **fictício, não auditado**. Para aferir um cliente, seriam necessários exportações datadas, conciliação contábil, logs de alteração de promessa, amostra de cards e aprovação de responsáveis. O pacote não contém dados pessoais reais.
