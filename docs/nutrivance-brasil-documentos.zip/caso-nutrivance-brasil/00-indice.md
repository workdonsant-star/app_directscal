# Nutrivance Brasil | índice do caso DS-001

**FICTÍCIO — conjunto editável para teste, 03/11/2026.** Nenhum documento é comprovação de cliente, assinatura, aceite real, implantação em produção ou avaliação longitudinal observada.

## Dados mestres e regras de leitura

| Campo | Valor do caso |
| --- | --- |
| Empresa | Nutrivance Brasil, nome e operação fictícios |
| Mercado | Suplementos nutricionais, vitaminas e bem-estar; marca própria; fabricação terceirizada |
| Sede e alcance | São Paulo, SP; distribuição nacional |
| Fundação | 2019; sete anos de operação em 2026 |
| Receita líquida de referência | R\$ 48,0 milhões no ano móvel nov/25–out/26 |
| Crescimento | 32% ante nov/24–out/25; base calculada R\$ 36,364 milhões |
| Pessoas | 86: 2 sócios, 6 líderes funcionais e 78 demais colaboradores |
| Canais | DTC próprio 45%, marketplaces 30%, B2B 25% da receita do ano móvel |
| Cenário | Receita cresce, margem e serviço caem; decisões de promoção, lançamento e reposição concentram-se na direção |

Os números e eventos de todos os arquivos são hipóteses e registros **sintéticos**. Datas posteriores a 03/11/2026 representam cenário futuro de teste, não execução ocorrida. Os arquivos da Fase III usam metas e roteiros de ensaio, sem declarar adoção real.

## Arquivos

**[Abrir o índice no Notion](https://app.notion.com/p/40d026c1ddec81d090fed0f672174643)**. As oito páginas editáveis estão como subpáginas, na mesma ordem da tabela.

| Arquivo | Conteúdo | Fase/etapas |
| --- | --- | --- |
| `01-perfil-organizacao.md` | Ficha, organograma, pessoas, RH, planejamento e configuração | I/01 |
| `02-financas-kpis-e-evidencias.md` | DRE, caixa, KPIs, sistemas, processos, ocorrências, atas e inventário de fontes | I/01–02 |
| `03-pesquisa-entrevistas-triangulacao.md` | Base recuperável, entrevistas, lacunas, matriz de triangulação | I/02 |
| `04-diagnostico-charter.md` | Causas, decisões críticas, prioridades, diagnóstico e charter | I/03–04 |
| `05-arquitetura-e-processos.md` | Estabilização, alternativas, estrutura alvo, direitos, RACI, fluxo, piloto e SOP | II/05–07 |
| `06-governanca-sistemas-mudanca.md` | Metas, rituais, ativos de gestão, arquitetura de dados e mudança | II/08–09 e transversal |
| `07-implantacao-transferencia-sustentacao.md` | Ondas, habilitação, adoção, operação assistida, transferência e avaliação futura | III/10–11 e avaliação |
| `08-matriz-de-testes.md` | Casos, resultados esperados, evidência, rastreabilidade e critérios de bloqueio | I–III |

## Fontes e limites

- [Metodologia v2 no Notion](https://app.notion.com/p/402026c1ddec80119aaecc9ec8ba7771): três fases, onze etapas, escopo adaptativo, triangulação e classificação da força das conclusões.
- Inspiração **apenas de segmento e porte**: [PINATI](https://app.notion.com/p/3e9026c1ddec81f1941dc0a683b180bf), [Vhita](https://app.notion.com/p/3e9026c1ddec812d9de9e34455929765), [Endogen](https://app.notion.com/p/3e9026c1ddec81be8ab9f8323561967b). Nenhum número, pessoa, cliente ou ocorrência desses prospects foi copiado para a Nutrivance.
- O repositório contém um [caso preliminar distinto](/Users/donsantos/Documents/GitHub/app_directscal/docs/caso-validacao-omdx/00-leia-me.md), da Nativa Forma, com agregados da pesquisa “Maturidade Q4” consultados em 03/11/2026. Não há vínculo documental entre essa pesquisa e a Nutrivance. Respostas individuais, texto integral das 30 perguntas, distribuição por setor, datas por resposta e consentimentos não foram recuperados neste trabalho. A tabela agregada é reproduzida em `03` com a sua proveniência e **não alimenta** o diagnóstico da Nutrivance.
- Na metodologia, grupos com menos de cinco pessoas não são reportados isoladamente. A base citada tem fundador n=1; qualquer relatório que o exponha deve ser bloqueado.
- A nomenclatura das seis dimensões do instrumento aplicado difere da metodologia v2; há sobreposição temática, sem equivalência automática, especialmente em Capacidade Adaptativa.

## Estado das entregas fictícias

Os artefatos de Fase I e II são **exemplos completos para ensaio**, com validações fictícias identificadas. Etapas dependentes de aprovação executiva, piloto com pessoas reais, publicação, ativação de agente, transferência e reaplicação do OMDx permanecem **não comprovadas**. A matriz de testes diz o que o sistema e o método devem mostrar quando usados em tenant de teste próprio.
