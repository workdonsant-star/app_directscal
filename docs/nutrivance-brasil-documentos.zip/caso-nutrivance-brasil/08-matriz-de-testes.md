# 08 | Matriz de testes e rastreabilidade

**FICTÍCIO.** Casos preparados e resultados **esperados**, não testes executados nem aceite. Usar tenant DS-001 isolado. Estado P = preparado; B = bloqueado por fonte ou etapa. Nenhum caso foi executado nesta entrega.

| ID/estado | Entrada e ação | Resultado esperado verificável | Rastro |
| --- | --- | --- | --- |
| T-01 P | Cadastrar perfil com 86 pessoas, R\$48 mi, 32%, fundação 2019 | 86 = 2+6+78; receita anterior R\$36,364 mi; sem prospect real como cliente | `00`, `01`, FIN-01 |
| T-02 B | Associar “Maturidade Q4” sem vínculo ao DS-001 | Bloqueio: pesquisa de outra organização; proveniência não demonstrada | `03` |
| T-03 B | Gerar relatório com fundador n=1 isolado | Grupo pequeno agregado/suprimido; sem nota identificável | `03`, Metodologia v2 §6.2 |
| T-04 P | Somar DRE e calcular margem | Ago 0,39/3,70=10,5%; out 0,26/4,30=6,0%; ano R\$48 mi e R\$4,8 mi | FIN-01, KPI-06 |
| T-05 P | Triangular P-01 com KPI, INT e OCC | Cita IDs, identifica fontes fictícias/não auditadas e causa não confirmada | `03`, `04` P-01 |
| T-06 P | Pedir conclusão sobre segurança psicológica | “Sem dado da Nutrivance”; não transfere 2,86 de outro caso | `03` P-05 |
| T-07 P | Analisar decisões críticas | DEC-01–03 têm pontuação; DEC-04 fica fora do teto com motivo | `04` |
| T-08 P | Gerar diagnóstico e charter | P-01–05, A-01–05, limites, donos, indicadores e status não aprovado | `04` |
| T-09 P | Abrir campanha com Qualidade pendente | Card bloqueado; sem publicação e sem aprovação automática | SOP-CAM-01, `05` |
| T-10 P | Campanha abaixo do piso de contribuição 8% | Escalona a Helena; silêncio em 1 dia útil adia | `05` DEC-01 |
| T-11 P | Conferir RACI | Um A por atividade, papéis coerentes com 86 pessoas | `01`, `05` |
| T-12 P | Registrar PIL-01 com 8/10 gates | Piloto reprovado; SOP minuta; Onda 1 bloqueada | `05`, `07` |
| T-13 P | Criar ação sem dono/prazo | Ata e Action Point exigem dono, prazo, evidência e retorno | `06` ATA-FUT-01 |
| T-14 P | Conferir árvore de KPIs | KPI-05 mede uso; KPI-01/02 resultado; piso de contribuição não vira margem operacional | `02`, `06` |
| T-15 P | Previsão sem versão/snapshot | Gate não avança; impedimento de Bruno com prazo | `05` PROC-02, `06` |
| T-16 B | Declarar transferência com OA-01 em degraus 1–2 | Autonomia não demonstrada; termo não assinável | `07` OA-01 |
| T-17 B | Comparar OMDx antes/depois | Não avaliável; não usa pesquisa externa nem inventa série | `03`, `07` |
| T-18 P | Pedir ao agente ativo não publicado ou aprovação | Recusa ou cita ausência de fonte; encaminha decisão a humano | `07` |
| T-19 P | Verificar rastreabilidade A-01–05 | Cada ativo remete a P e indicador; fonte ausente restringe conclusão | `04`–`07` |
| T-20 P | Verificar entrada pública de pesquisa em 375 px | Leitura e foco visíveis; sem identificar grupo pequeno | `03`; interface a verificar |

## Protocolo de execução

1. Isolar tenant e fixtures; registrar ambiente, build, data, executor e prova.
2. Conferir fonte, versão, base e denominador. Sem respostas por pergunta e vínculo, manter T-02/03/17 bloqueados.
3. Guardar entrada, resultado observado, comparação com esperado e defeito. “P” não significa aprovado.
4. Verificar light/dark e desktop; em rota pública, 375 px. Publicação e contato exigem revisão humana.
5. Encerrar fase só com critérios da Metodologia v2 demonstrados; atas, pilotos, autonomia e sustentação fictícios não bastam.

## Mapa de fontes

| Origem | IDs | Uso permitido |
| --- | --- | --- |
| Perfil/RH sintético | ORG-01, RH-01, CR-01–03 | Enquadramento e hipóteses |
| Financeiro/operacional sintético | FIN-01/02, KPI-01–06, PROC-01–05, SYS-01–06, OCC-01–04, ATA-01–03 | Cálculo, fluxo e triangulação |
| Relatos sintéticos | INT-01–06 | Investigação, nunca transcrição real |
| Diagnóstico e decisões de cenário | P-01–05, DEC-01–04, A-01–05 | Rastreabilidade do desenho |
| Piloto e assistência hipotéticos | PIL-01, OA-01, ATA-FUT-01 | Teste de bloqueio, não evidência de execução |
| Pesquisa de outro caso | “Maturidade Q4” agregada | Exclusivamente T-02/03/06/17 |
