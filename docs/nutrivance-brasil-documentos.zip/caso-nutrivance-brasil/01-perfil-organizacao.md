# 01 | Perfil e enquadramento

**FICTÍCIO.** Ficha de Enquadramento Empresarial, organograma e insumos de RH/planejamento. Data de referência: out/26.

## Modelo e direção

A Nutrivance Brasil é uma marca fictícia fundada em 2019 por Helena Duarte (diretora-geral) e Rafael Nogueira (diretor de produto). Vende proteína, creatina, vitaminas e fórmulas de bem-estar sob marca própria. Pesquisa de produto, qualidade, comercialização e experiência do cliente são internas; dois fabricantes terceirizados produzem; um operador logístico atende o país. O canal próprio representa 45% da receita anual móvel, marketplaces 30% e distribuidores/varejo especializado B2B 25%. O volume crescente de SKUs e campanhas pressiona estoque, caixa e promessas de entrega.

**Direção declarada, não validada:** ampliar distribuição sem reduzir segurança de produto e buscar margem operacional de pelo menos 10% em 2027. A equipe ainda não recebeu metas por canal com premissas de estoque e margem. Trade-off proposto para teste: segurar uma campanha até liberar qualidade, disponibilidade e margem, mesmo com perda de velocidade comercial.

## Estrutura atual e quadro de pessoal

| Área | Pessoas, incluindo líder | Liderança | Entrega e interface crítica |
| --- | ---: | --- | --- |
| Direção e estratégia | 2 | Helena e Rafael, sócios | Prioridade, capital, portfólio; decisões excepcionais |
| Comercial B2B | 11 | Caio Martins | Contratos e previsão de distribuidores → Supply |
| Growth/DTC | 14 | Luiza Costa | Campanhas e oferta → Finanças, Qualidade e Supply |
| Operações/Supply | 24 | Bruno Almeida | Previsão, compra, operador logístico e prazo → Canais |
| Produto/Qualidade | 10 | Marina Reis | Fórmula, rótulo e liberação → Growth e Supply |
| Finanças/People | 9 | Paula Azevedo | DRE, caixa, margem, quadro e capacitação → todas |
| Atendimento/CS | 16 | Tiago Lima | Promessa ao cliente, chamados e devolução → Supply |
| **Total** | **86** | **2 sócios + 6 líderes + 78 demais** | |

O organograma formal coloca os seis líderes sob Helena; Rafael coaprova produto e qualidade. Na prática, Caio, Luiza e Bruno recorrem a Helena em promoções, reposições urgentes e datas de lançamento, mesmo em faixas não estratégicas. A configuração cria dependência decisória, sem provar por si só atraso ou causa financeira.

## Pessoas e capacidade

O quadro sintético de RH de out/26 registra 86 vínculos ativos, 7 admissões e 3 saídas no trimestre ago–out; a rotatividade trimestral aproximada é 3/86 = 3,5%, sem anualização. Há 8 vagas planejadas para 2027, condicionadas a margem e caixa. Três analistas dominam as planilhas de previsão e uma só analista domina a integração manual ERP–marketplace; a cobertura de férias foi testada em apenas um fluxo. Formação fictícia: 6 líderes treinados em indicadores, 2 em condução de rituais, nenhum certificado para aprovar formulação fora de Qualidade. Pessoas entrevistadas no arquivo `03` são personagens, não respondentes identificados da pesquisa.

## Mapa de configuração nas seis lentes

| Lente | Estado sintético | Evidência/limite |
| --- | --- | --- |
| Estrutura | Seis áreas com liderança; alçada excepcional pouco definida | ORG-01; alçadas em ata incompleta |
| Coordenação | Reunião comercial e operacional semanal, sem única fila de impedimentos | ATA-01–03 |
| Capacidades | Qualidade formal; previsão dependente de três analistas | RH-01, PROC-02 |
| Governança | DRE mensal, decisões por mensagem, ações sem prazo | FIN-01, ATA-03 |
| Dependências | Helena decide exceções; planilha de demanda concentra know-how | DEC-01, OCC-03 |
| Adaptação | Campanhas crescem mais rápido que atualização de processo | OCC-01–04; percepção OMDx da Nutrivance ausente |

## Inventário de tensões

| ID | Manifestação | Categoria interpretativa | Estado |
| --- | --- | --- | --- |
| CR-01 | Aprovações de campanha e reposição passam por Helena | Autonomia e liderança | Hipótese apoiada por DEC-01 e ATA-03; tempos ainda amostrais |
| CR-02 | Informação de prazo diverge entre canais e operador | Coordenação, categoria DirectScal | Sintoma em OCC-04 e KPI-02; causa aberta |
| CR-03 | Margem diminui com crescimento de receita | Controle | FIN-01 confirma variação sintética; mecanismo não demonstrado |

**Validação formal do cliente:** não existe; os personagens e assinaturas deste pacote são fictícios. O teto de decisões críticas para análise é 3, registrado antes da seleção.
