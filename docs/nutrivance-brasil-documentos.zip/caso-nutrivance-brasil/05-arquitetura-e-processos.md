# 05 | Arquitetura organizacional e processos críticos

**FICTÍCIO — desenho de Fase II.** Nenhum piloto ou validação por operador ocorreu de fato. Responde às prioridades A-01, A-02 e A-05 do charter `04`.

## Etapa 05: estabilização transitória

Quadro único de coordenação por quatro semanas de ensaio: ID, fluxo, responsável, impedimento, decisão requerida, prazo e evidência. Reunião diária de 15 minutos em Supply/Growth/Qualidade e revisão de 30 minutos às sextas com Paula. Escalonar risco de promessa em 4 horas úteis ao dono do fluxo; margem abaixo do piso e qualidade pendente impedem publicação. A DirectScal conduziria a primeira semana; Luiza conduziria a segunda com observação; na terceira, liderança interna conduz. O quadro migra para o ritual semanal da Etapa 08 ou é descartado. Medidas: KPI-01, KPI-04/05 e tempo de bloqueio por gate, com linha de base do arquivo `02`. Sem execução observada.

## Etapa 06: critérios e alternativas

Critérios de desenho: 1) segurança de produto inegociável; 2) promessa comercial baseada em saldo vendável; 3) margem por campanha antes da ativação; 4) decisão mais próxima do fluxo, com exceções registradas; 5) uma fonte oficial por dado. Alternativa A mantém organograma e cria dono do fluxo com alçadas; alternativa B cria uma diretoria de receita reunindo Comercial/Growth/CS. A alternativa A foi escolhida **no cenário** por menor perturbação para 86 pessoas e prazo curto; sua eficácia depende de piloto. O organograma alvo conserva 2 sócios, 6 áreas e 86 pessoas, sem demissões ou contratações. Luiza responde pelo fluxo de campanha, Bruno pela disponibilidade, Marina por qualidade, Paula por margem e Tiago por promessa/retorno. Helena retém investimento excepcional e mudança estratégica de canal.

## Direitos de decisão

| Decisão | Decide no desenho proposto | Consulta obrigatória | Escalona quando | Registro |
| --- | --- | --- | --- | --- |
| DEC-01 campanha dentro do piso de 8% de margem de contribuição fictícia | Luiza | Paula, Bruno, Marina se envolver rótulo/alegação | Piso não atingido, saldo insuficiente ou risco regulatório | Card com três gates |
| DEC-01 exceção abaixo de 8% | Helena | Paula e Luiza | Sempre antes da publicação; sem resposta até 1 dia útil, campanha adiada | Decisão e justificativa no card |
| DEC-02 reposição dentro do orçamento e fornecedor homologado | Bruno | Paula e Marina | Antecipação de caixa > R\$ 150 mil ou fornecedor novo | Pedido ERP + previsão versionada |
| DEC-03 anúncio de novo SKU | Rafael | Marina, Bruno, Luiza | Qualidade não liberou: anúncio bloqueado, sem override comercial | Checklist de liberação |

O piso de 8% é hipótese do cenário e difere da margem operacional da DRE; os dois indicadores não são intercambiáveis. Incentivo comercial atual por receita bruta criaria conflito; proposta de revisão inclui margem e promessa, sem alterar remuneração antes de acordo de RH.

## Etapa 07: fluxo e seleção de padronização

Fluxo de valor: demanda/campanha → avaliação de produto e qualidade (PROC-03) → previsão/reposição (PROC-02) → decisão de oferta (PROC-01) → pedido/expedição (SYS-01/02) → atendimento (PROC-05). PROC-01 e PROC-02 foram selecionados por frequência, risco de margem/serviço e transferência entre áreas. PROC-03 recebe checklist obrigatório por risco de qualidade. PROC-04 e PROC-05 ficam no inventário para observação; não há SOP nova para cada atividade.

**Estado atual PROC-01:** briefing → data agendada → consultas por mensagens → possível reabertura → publicação; falta anexo de margem, saldo e liberação. **Estado futuro:** briefing com SKU/canal/volume → Quality gate → saldo vendável e reserva → margem de contribuição projetada por Paula → decisão na alçada → promessa revisada por Tiago → publicação → monitoramento 48h → retro de exceções. Se qualquer gate falhar, retorna ao dono com motivo e nova data; não publica por silêncio.

**Estado atual PROC-02:** planilha de previsão editada sem versão → pedido → ajuste manual ERP. **Estado futuro:** versão semanal com autor/data/premissas → confronto com saldo/lead time → Bruno decide dentro da alçada → Paula valida caixa se limiar excedido → pedido ERP → conferência de saldo. Dois substitutos documentados para a analista sênior.

## RACI do processo de campanha

R = executa; A = único responsável final; C = consultado; I = informado. Cada linha tem exatamente um A.

| Atividade | Luiza/Growth | Bruno/Supply | Marina/Qualidade | Paula/Finanças | Tiago/CS | Helena |
| --- | --- | --- | --- | --- | --- | --- |
| Briefing e objetivo | A/R | C | C | C | I | I |
| Liberação de rótulo/alegação | I | I | A/R | I | I | I |
| Saldo vendável e reserva | C | A/R | I | C | I | I |
| Margem projetada | C | C | I | A/R | I | I |
| Aprovar campanha dentro da alçada | A/R | C | C | C | I | I |
| Aprovar exceção abaixo do piso | R | C | C | C | I | A |
| Publicar promessa ao cliente | C | C | I | I | A/R | I |
| Revisar resultado e exceções | A | R | C | R | R | I |

## Ativo de gestão SOP-CAM-01 v0.1

**Dono:** Luiza. **Gatilho:** novo card de campanha. **Entrada obrigatória:** SKU, canal, preço, volume, data, custo/frete estimado, saldo vendável e estado de qualidade. **Passos:** 1) abrir card; 2) Marina libera ou bloqueia qualidade; 3) Bruno confirma e reserva saldo; 4) Paula anexa margem e piso; 5) Luiza decide na alçada, ou Helena decide exceção; 6) Tiago valida promessa; 7) publicar e monitorar 48h. **Saída:** card com decisão, data, versão das fontes e responsável. **Falha:** gate ausente bloqueia; registrar impedimento e escalar conforme quadro. **Métrica de uso:** KPI-05. **Revisão:** mensal por Luiza e Marina. **Status:** minuta fictícia, requer piloto e validação de executores antes de publicação.

## Piloto previsto e registro fictício

Plano: 10 campanhas de baixo risco, 2 SKUs e 2 canais, em janeiro/27; medir tempo de gate, reabertura e promessa. Critério: 9/10 cards com gates antes de publicar; nenhuma publicação com Qualidade bloqueada; ao menos 2 operadores conseguem aplicar SOP sem intervenção. Registro de ensaio PIL-01: “8/10 cards completos; 2 falharam por saldo sem carimbo de tempo; SOP revisada para exigir snapshot ERP.” **Isto é um resultado hipotético para teste de reprovação**, não ocorreu. Resultado esperado do sistema: piloto reprovado, SOP não institucionalizada e ação corretiva aberta.
