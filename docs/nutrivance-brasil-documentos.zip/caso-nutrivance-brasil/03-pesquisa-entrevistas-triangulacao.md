# 03 | Pesquisa, entrevistas e triangulação

**FICTÍCIO nos relatos e na empresa.** O único agregado de questionário disponível veio de um caso preliminar distinto; é registrado aqui para testar a detecção de incompatibilidade de origem, **sem ser atribuído à Nutrivance Brasil**.

## Estado da pesquisa recuperável

O arquivo `docs/caso-validacao-omdx/06-triangulacao-e-validacao.md` registra uma consulta feita em 03/11/2026 à pesquisa “Maturidade Q4”: 46 sessões concluídas, com 30 respostas por sessão (1.380 respostas); fundador n=1, liderança n=5, operação n=40. O mesmo pacote atribui a pesquisa a uma organização cadastrada diferente da empresa fictícia “Nativa Forma”. Não há chave de empresa, consentimento ou vínculo com a Nutrivance. Por isso, os números abaixo são **referência externa de teste**, excluída do diagnóstico DS-001.

| Dimensão aplicada no sistema | Fundador n=1 | Liderança n=5 | Operação n=40 |
| --- | ---: | ---: | ---: |
| Cultura e Segurança Psicológica | 4,00 | 3,80 | 2,86 |
| Visão e Alinhamento Estratégico | 4,80 | 3,80 | 2,86 |
| Comunicação e Gestão do Trabalho | 4,00 | 2,84 | 2,86 |
| Processos e Execução Operacional | 3,00 | 2,84 | 1,89 |
| Liderança, Delegação e Autonomia | 4,00 | 3,80 | 2,86 |
| Performance, Prioridade e Foco | 4,00 | 3,80 | 2,86 |
| Média de todas as respostas | 3,97 | 3,48 | 2,69 |

**Dados não recuperados:** respostas por pessoa ou pergunta; redação integral e versão do instrumento de 30 itens; data/versão de cada resposta; distribuição por setor; base de convidados e taxa de resposta; vínculo verificável da pesquisa com Nutrivance; reaplicação após intervenção. Não reconstruir esses dados pelas médias. O grupo fundador n=1 não pode ser publicado isoladamente segundo o limiar de cinco da Metodologia v2. A pesquisa permanece descrita como ativa no pacote anterior, logo não é desfecho final. As seis dimensões do instrumento não equivalem automaticamente às seis da Metodologia v2; a dimensão de Capacidade Adaptativa não aparece como dimensão própria no instrumento aplicado.

**Base OMDx da Nutrivance:** não recuperada. Campo de diagnóstico: `sem dado`, não zero, não média 2,69. Uma coleta sintética futura pode ser criada em tenant DS-001, mas deve ter respostas e proveniência próprias.

## Consolidado de entrevistas fictícias

| ID/personagem | Relato fictício | Episódio relacionado | Checagem necessária |
| --- | --- | --- | --- |
| INT-01 Helena, direção | “Crescemos, mas decisões de exceção chegam sem alternativas e prazo.” | ATA-03, OCC-03 | Log de aprovações e tempos |
| INT-02 Luiza, Growth | “Às vezes agendamos campanha antes de reservar saldo vendável.” | OCC-01 | Sequência de eventos do card e ERP |
| INT-03 Bruno, Supply | “A previsão está na planilha; nem sempre a mudança alcança canais.” | PROC-02, OCC-04 | Versões da previsão e promessa |
| INT-04 Marina, Qualidade | “Data pública precisa esperar rótulo e liberação do fabricante.” | OCC-02 | Histórico da liberação |
| INT-05 Tiago, Atendimento | “A equipe recebeu prazo antigo em oito chamados que revisei.” | OCC-04 | Auditoria dos 29 restantes |
| INT-06 Paula, Finanças | “A DRE fecha; a margem por campanha chega tarde para decidir.” | FIN-01, OCC-03 | Reconciliação por campanha e canal |

São falas fabricadas para o ensaio. Não têm gravação, consentimento, transcrição original nem confirmação de entrevistado.

## Matriz de triangulação preliminar

| Achado | Pesquisa Nutrivance | Entrevista | Registro documental | Classificação e limite |
| --- | --- | --- | --- | --- |
| P-01: promessa de entrega se deteriorou | **Ausente** | INT-03/05 | KPI-01/02, OCC-04 | Sinal em duas fontes fictícias; categorias e promessa precisam de auditoria |
| P-02: campanhas atravessam gates incompletos | **Ausente** | INT-02/04/06 | KPI-04/05, OCC-01–03 | Convergência fictícia; sem cronologia completa ou causalidade |
| P-03: exceções concentram-se na direção | **Ausente** | INT-01 | ATA-03, ORG-01 | Hipótese plausível; volume e tempo de decisão não medidos |
| P-04: margem operacional caiu | **Ausente** | INT-06 | FIN-01 | Variação documentada no cenário; causa financeira em aberto |
| P-05: segurança psicológica é baixa | **Ausente** | Nenhuma | Nenhum | **Não concluir**; o dado de outro caso não pode ser transferido |

Uma triangulação com duas fontes **fictícias** testa a lógica do método; não equivale a evidência independente auditada. O diagnóstico `04` classifica força e limitações. A pesquisa externa serve somente aos testes T-02 e T-03, que devem bloquear associação indevida e exposição de grupo pequeno.
