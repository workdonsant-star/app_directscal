# 04 | Diagnóstico organizacional e charter

**FICTÍCIO — rascunho consultivo de Fase I, não aprovado por cliente.** Usa somente o cenário DS-001 dos arquivos `01`–`03`; não incorpora as médias da pesquisa externa. Nenhuma relação causal é declarada como comprovada.

## Relatório executivo OMDx: leitura limitada

A Nutrivance cresceu 32% até R\$ 48 milhões e chegou a 86 pessoas em sete anos. Entre agosto e outubro de 2026, a receita mensal aumentou de R\$ 3,70 mi para R\$ 4,30 mi, mas o resultado operacional gerencial caiu de R\$ 0,39 mi para R\$ 0,26 mi. O envio no prazo caiu de 94% para 85%, e os chamados por prazo divergente subiram de 16 para 37. Os registros sugerem falhas nas interfaces campanha–estoque–qualidade–promessa e concentração de exceções, mas a ausência de respostas OMDx vinculadas à empresa e de registros auditados impede um diagnóstico encerrado.

**Leitura por dimensão v2:** visão/estratégia = direção declarada, desdobramento não verificado; arquitetura decisória = hipótese de concentração; cultura/confiança = sem dado; fluxos de valor = sinais de retrabalho e espera; governança de desempenho = DRE mensal sem margem de campanha tempestiva; capacidade adaptativa = sem medida própria. Não converter isso em nota OMDx.

## Mapa de problemas, causas e crises

| ID | Sintoma | Evidência | Hipótese de mecanismo | Força da conclusão |
| --- | --- | --- | --- | --- |
| P-01 | Envio no prazo 94% → 85% e chamados 16 → 37 | KPI-01/02, OCC-04, INT-03/05 | Promessa não recebe revisão de estoque em tempo | Sintoma observado no cenário; causa **não confirmada** |
| P-02 | Gate completo de campanha 3/12 → 2/15; reaberturas 2/12 → 6/15 | KPI-04/05, OCC-01–03, INT-02/04/06 | Lançamento aceita data antes de qualidade, estoque e margem | Associação plausível; sequência de eventos incompleta |
| P-03 | Exceções sobem à direção sem prazo | ORG-01, ATA-03, INT-01 | Alçada pouco clara prolonga decisão | Hipótese não confirmada; falta amostra de tempos |
| P-04 | Margem operacional 10,5% → 6,0% | FIN-01, INT-06 | Mix, promoções, frete ou CPV | Variação confirmada no cenário; causa aberta |
| P-05 | Dependência de planilhas e pessoas específicas | RH-01, PROC-02, INT-03 | Falta de versionamento/cobertura aumenta espera | Hipótese não confirmada |

Crises interpretativas: CR-01 (autonomia/liderança), CR-02 (coordenação) e CR-03 (controle) coexistem; não se atribui estágio universal de crescimento. Rastreabilidade: P-01 ↔ CR-02 ↔ ativos A-02/A-03; P-02 ↔ CR-02 ↔ A-01/A-02; P-03 ↔ CR-01 ↔ A-01/A-04; P-04 ↔ CR-03 ↔ A-03/A-04; P-05 ↔ CR-02 ↔ A-02/A-05.

## Decisões críticas e teto de análise

Teto fixado na ficha: **3**. Escala de seleção fictícia: impacto, frequência, atraso e transversalidade de 1 a 3; soma máxima 12. Os pontos são julgamento de desenho, não medida do cliente.

| Decisão | Impacto | Frequência | Atraso | Transversalidade | Total | Amostra e limite |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| DEC-01 publicar campanha com desconto/estoque | 3 | 3 | 3 | 3 | 12 | OCC-01/03 e ATA-01; tempo sem log |
| DEC-02 antecipar reposição de SKU crítico | 3 | 3 | 2 | 3 | 11 | PROC-02, RH-01; faltam pedidos datados |
| DEC-03 anunciar data de novo SKU | 3 | 2 | 2 | 3 | 10 | OCC-02, ATA-02; liberação não anexada |
| DEC-04 ressarcimento extraordinário | 2 | 2 | 1 | 2 | 7 | **Fora do teto**; menor impacto e sem amostra |

## Prioridade e plano de ação

| Ordem/ID | Intervenção | Dono fictício | Dependência | Indicador e aceite de ensaio |
| --- | --- | --- | --- | --- |
| 1 / A-01 | Alçadas para campanha, reposição e novo SKU | Helena + Paula | Decisões DEC-01–03 e piso de margem | 100% das exceções com decisor, prazo e registro em piloto |
| 2 / A-02 | Gate e fluxo ponta a ponta de campanha/lançamento | Luiza + Marina + Bruno | A-01 e fonte de saldo | ≥90% dos cards com qualidade, estoque e margem antes de publicar |
| 3 / A-03 | Painel semanal serviço/margem | Paula + Bruno + Tiago | Definições e auditoria KPI-01–06 | Dois ciclos com denominadores e decisão registrada |
| 4 / A-04 | Rituais e Action Points com escalonamento | Helena + líderes | A-01–03 | Ações com dono/prazo e revisão por quatro semanas |
| 5 / A-05 | Cobertura e versionamento da previsão | Bruno + People | Mapeamento PROC-02 | Dois substitutos executam previsão sem analista sênior |

Pontuação de priorização fictícia: impacto/urgência/viabilidade (1–3): A-01 3/3/3=9; A-02 3/3/2=8; A-03 3/2/3=8; A-04 2/2/3=7; A-05 2/2/2=6. A-02 precede A-03 na ordem por dependência do gate, não por diferença de pontos. **Escopo adaptativo:** executar etapas 05–09 para os fluxos críticos; não redesenhar toda a empresa nem trocar o ERP.

## Charter de intervenção DS-001 — proposta para ensaio

**Problema:** crescimento de canais e produtos supera a coordenação entre ofertas, estoque, qualidade, margem e promessa. **Objetivo:** elevar a confiabilidade do gate de campanhas e do serviço, com alçadas claras e governança proporcional. **Escopo:** campanhas DTC, reposição prioritária e lançamento de SKU; seis áreas envolvidas. **Fora do escopo:** formulação, aconselhamento de saúde, ERP novo, reestruturação societária e contratação automática.

**Patrocínio fictício:** Helena; responsável interno: Paula; donos por fluxo: Luiza, Bruno e Marina. **Janela de ensaio:** 09/11/26 a 30/04/27. **Marcos:** estabilização 20/11; desenho 18/12; pilotos 22/01/27; ondas 05/02–19/03; autonomia 16/04; avaliação de sustentação prevista 30/04. Datas futuras são roteiro de teste. **Recursos propostos:** 4 horas/semana de cada líder e 1 analista por área piloto. **Restrições:** não publicar campanha sem liberação de Qualidade quando aplicável; limite de duas mudanças simultâneas por área.

**Critérios de saída de Fase I:** ficha conferida por responsável, base OMDx da Nutrivance identificada ou ausência explicitada, hipóteses e limites apresentados, prioridades e alçadas aprovadas em ata. **Estado real deste pacote:** não atendido; registro de validação executiva é uma ensaio de agenda, sem assinatura. Fase II e III abaixo são artefatos de ensaio condicionais ao charter, não prova de contratação ou implantação.
